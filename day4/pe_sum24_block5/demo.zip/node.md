##  Cài axios
npm i axios

## cài json-server
npm i json-server

## chạy json-server
json-server -w file_name -p port_name