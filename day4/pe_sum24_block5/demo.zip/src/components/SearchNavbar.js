import React from 'react'
import { useContext } from 'react'
import AppContext from '../provider/Context';

function SearchNavbar() {
   const {subjects, searchNav, setSearchNav} = useContext(AppContext); 
  return (
    <div>
      <h3>Subjects</h3>
      <ul style={{listStyle:'none'}}>
      {subjects.map((subject, index) => (
        <li key={subject.id}><a href='#' 
        onClick={handleSearchNav}>{subject.name}</a></li>
      ))}
      </ul>
    </div>
  )
}

export default SearchNavbar